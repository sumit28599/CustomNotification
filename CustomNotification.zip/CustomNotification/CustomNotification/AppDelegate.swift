//
//  AppDelegate.swift
//  CustomNotification
//
//  Created by apple on 12/02/24.
//

import UIKit
import OneSignal
import UserNotifications
import GoogleMaps
import GooglePlaces

//88655fd0-5228-4c33-985d-e23185b18ae0
@main
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
       
        OneSignal.setLogLevel(.LL_VERBOSE, visualLevel: .LL_NONE)
        OneSignal.initWithLaunchOptions(launchOptions, appId: "88655fd0-5228-4c33-985d-e23185b18ae0")
        OneSignal.promptForPushNotifications(userResponse: { accepted in
          print("User accepted notifications: \(accepted)")
        })
        
        GMSServices.provideAPIKey("AIzaSyC0H-dWw3VkYVb9-8Ujmcg1NGVUd45VbuE")
        GMSPlacesClient.provideAPIKey("AIzaSyC0H-dWw3VkYVb9-8Ujmcg1NGVUd45VbuE")
       
        return true
    }


    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }
    
       func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
           let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
           print("APNs device token: \(deviceTokenString)")
       }
       
       func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
           print("APNs registration failed: \(error)")
       }
}

