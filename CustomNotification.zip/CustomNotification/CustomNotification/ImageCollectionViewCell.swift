//
//  ImageCollectionViewCell.swift
//  CustomNotification
//
//  Created by apple on 20/02/24.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imagesPDF: UIImageView!
}
