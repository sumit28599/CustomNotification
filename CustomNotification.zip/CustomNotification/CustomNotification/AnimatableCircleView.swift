//
//  AnimatableCircleView.swift
//  CircleBorderAnimation
//
//  Created by Akshit Zaveri on 02/05/20.
//  Copyright © 2020 Akshit Zaveri. All rights reserved.
//

import UIKit

final class AnimatableCircleView: UIView {

  // MARK: - UI objects

//  private lazy var circleView: UIView = {
//    let view = UIView()
//    view.translatesAutoresizingMaskIntoConstraints = false
//    view.backgroundColor = .clear
//    view.clipsToBounds = true
//    return view
//  }()

  private lazy var miniCircleView: UIView = {
    let view = UIView()
    view.translatesAutoresizingMaskIntoConstraints = false
    view.backgroundColor = .orange
    return view
  }()

  // MARK: - Initializers and Life cycle

  required init?(coder: NSCoder) {
    super.init(coder: coder)
    self.setup()
  }

  private func setup() {
    self.clipsToBounds = false

  //  self.addSubview(self.circleView)
//    NSLayoutConstraint.activate([
//      self.circleView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//      self.circleView.topAnchor.constraint(equalTo: self.topAnchor),
//      self.circleView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//      self.circleView.bottomAnchor.constraint(equalTo: self.bottomAnchor)
//    ])

    self.addSubview(self.miniCircleView)
    NSLayoutConstraint.activate([
      self.miniCircleView.widthAnchor.constraint(equalToConstant: 12),
      self.miniCircleView.heightAnchor.constraint(equalToConstant: 12)
    ])
  }

  override func layoutSubviews() {
    super.layoutSubviews()
  //  self.circleView.layer.cornerRadius = self.circleView.frame.width / 2.0
    self.miniCircleView.layer.cornerRadius = self.miniCircleView.frame.width / 2.0

    self.miniCircleView.center = self.getPoint(for: -90)
  }

  // MARK: - Animation

  func startAnimating() {
    let path = UIBezierPath()
    let initialPoint = self.getPoint(for: -90)
    path.move(to: initialPoint)
  //  for angle in -89...0 { path.addLine(to: self.getPoint(for: angle)) }
    for angle in 1...270 { path.addLine(to: self.getPoint(for: angle)) }
    path.close()
    self.animate(view: self.miniCircleView, path: path)
  }

  private func animate(view: UIView, path: UIBezierPath) {
    let animation = CAKeyframeAnimation(keyPath: "position")
    animation.path = path.cgPath
    animation.repeatCount = 1
    animation.duration = 5
    view.layer.add(animation, forKey: "animation")
  }

  private func getPoint(for angle: Int) -> CGPoint {
    let radius = Double(25)
//      let radius = Double(self.circleView.layer.cornerRadius)
    let radian = Double(angle) * Double.pi / Double(180)
    let newCenterX = radius + radius * cos(radian)
    let newCenterY = radius + radius * sin(radian)

    return CGPoint(x: newCenterX, y: newCenterY)
  }
}




public class CircleProgressView: UIView {
    private var radius: CGFloat { (bounds.height - lineWidth) / 2 }
    private let baseLayer = CAShapeLayer()
    private let progressLayer = CAShapeLayer()
    private let progress: CGFloat
    private let lineWidth: CGFloat = 10.0

    required public init?(coder aDecoder: NSCoder) {
        fatalError()
    }

    public init(progress: CGFloat, baseColor: UIColor, progressColor: UIColor) {
        self.progress = progress
        
        for layer in [baseLayer, progressLayer] {
            layer.fillColor = UIColor.clear.cgColor
            layer.lineWidth = lineWidth
            layer.lineCap = .round
        }
        baseLayer.strokeColor = baseColor.cgColor
        baseLayer.strokeEnd = 1.0

        progressLayer.strokeColor = progressColor.cgColor
        progressLayer.strokeEnd = 0.0

        super.init(frame: .zero)

        layer.addSublayer(baseLayer)
        layer.addSublayer(progressLayer)
    }

    public func animateCircle(duration: TimeInterval, delay: TimeInterval) {
        progressLayer.removeAnimation(forKey: "circleAnimation")
        progressLayer.strokeEnd = 0
        addAnimation(duration: duration, delay: delay)
    }

    override open func layoutSubviews() {
        super.layoutSubviews()
        baseLayer.frame = bounds
        progressLayer.frame = bounds

        let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
        let basePath = UIBezierPath(arcCenter: center, radius: radius, startAngle: .initialAngle, endAngle: .endAngle(progress: 1), clockwise: true)
        let progressPath = UIBezierPath(arcCenter: center, radius: radius, startAngle: .initialAngle, endAngle: .endAngle(progress: progress), clockwise: true)
        baseLayer.path = basePath.cgPath
        progressLayer.path = progressPath.cgPath
    }
}

private extension CircleProgressView {
    func addAnimation(duration: TimeInterval, delay: TimeInterval) {
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.beginTime = CACurrentMediaTime() + delay
        animation.duration = duration
        animation.fromValue = 0
        animation.toValue = 1
        animation.timingFunction = CAMediaTimingFunction(name: .easeIn)
        animation.fillMode = .forwards
        animation.isRemovedOnCompletion = false
        progressLayer.add(animation, forKey: "circleAnimation")
    }
}

private extension CGFloat {
    static var initialAngle: CGFloat = -(.pi / 2)

    static func endAngle(progress: CGFloat) -> CGFloat {
        .pi * 2 * progress + .initialAngle
    }
}
