//
//  AppConstants.swift
//  CustomNotification
//
//  Created by apple on 19/02/24.
//

import Foundation
import UIKit
struct AppConstants{
    static var Lat = ""
    static var Log = ""
    }

extension UIView {
    func makeCircularView(){
        self.layer.cornerRadius = self.frame.height/2
        self.layer.masksToBounds = true
    }
}
