//
//  ViewController.swift
//  CustomNotification
//
//  Created by apple on 12/02/24.
//

import UIKit
import GoogleMaps
import CoreLocation
import PDFKit
import UniformTypeIdentifiers
import Network
import WidgetKit

struct YourWidgetContent {
    var title: String
    var description: String
}

class ViewController: UIViewController,  GMSMapViewDelegate, UIDocumentPickerDelegate {
    
    @IBOutlet weak var circleView: AnimatableCircleView!
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var wifiView: AnimatableCircleView!
    @IBOutlet weak var locationImageOff: UIImageView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var notificationsView: AnimatableCircleView!
    @IBOutlet weak var pdfView: PDFView!
    @IBOutlet weak var networkView: UIView!
    @IBOutlet weak var locationImageOn: UIImageView!
    @IBOutlet weak var notificationImage: UIImageView!
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    var images: [UIImage] = []
    let monitor = NWPathMonitor()
    let greaterView = UIView(frame: .init(x: 0, y: 0, width: 200, height: 200))
    let circleView1 = CircleProgressView(progress: 0.25, baseColor: .lightGray, progressColor: .orange)
    let locationManager = CLLocationManager()
    let queue = DispatchQueue(label: "NetworkMonitor")
    let current = UNUserNotificationCenter.current()

    override func viewDidLoad() {
        super.viewDidLoad()
        initialData()
//        showLiveNotification()
        
    }
    
    func showLiveNotification() {
                let content = UNMutableNotificationContent()
                content.title = "Live Widget-Style Notification"
                content.body = "This is a live notification example."
                content.sound = UNNotificationSound.default
                // Set up your widget content here
                let widgetContent = YourWidgetContent(title: "Special Deal", description: "50% off on orders!")
                // Set widget content in notification's user info
                content.userInfo = ["widgetContent": widgetContent]
                // Create a notification request
                let request = UNNotificationRequest(
                    identifier: UUID().uuidString,
                    content: content,
                    trigger: nil
                )
                // Schedule the notification
                UNUserNotificationCenter.current().add(request)
            }
   
    func initialData() {
        
        let debitOverdraftNotifCategory = UNNotificationCategory(identifier: "debitOverdraftNotification", actions: [], intentIdentifiers: [], options: [])
        UNUserNotificationCenter.current().setNotificationCategories([debitOverdraftNotifCategory])
        
        //        greaterView.addSubview(circleView1)
        //        circleView1.bounds = CGRect(x: 0, y: 0, width: 120, height: 120)
        //        circleView1.center = greaterView.center
        //        circleView1.animateCircle(duration: 0.5, delay: 0.5)
        circleView.makeCircularView()
        wifiView.makeCircularView()
        notificationsView.makeCircularView()
        pdfView.displayMode = .singlePage // Single page
        pdfView.displayMode = .singlePageContinuous // Continuous scrolling
        pdfView.displayMode = .twoUp
        mapView.delegate = self
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        imageCollectionView.delegate = self
        imageCollectionView.dataSource = self
        
        mapView.isHidden = true
        pdfView.isHidden = false
        networkView.isHidden = true
        if CLLocationManager.locationServicesEnabled() {
            locationManager.requestLocation()
            mapView.isMyLocationEnabled = true
            mapView.settings.myLocationButton = true
            mapView.settings.compassButton = true
        } else {
            locationManager.requestWhenInUseAuthorization()
        }
        
        //  displayPDF()
        if let pdfURL = Bundle.main.url(forResource: "sample", withExtension: "pdf") {
            let images = convertPDFToImages(pdfURL: pdfURL)
        }
        
    }
    
    func displayPDF() {
        guard let path = Bundle.main.path(forResource: "sample", ofType: "pdf") else { return }
        let url = URL(fileURLWithPath: path)
        guard let pdfDocument = PDFDocument(url: url) else { return }
        
        pdfView.displayMode = .singlePageContinuous
        pdfView.autoScales = true
        pdfView.displayDirection = .vertical
        pdfView.document = pdfDocument
        // Enable automatic scaling of the PDF view to fit the content within the available space
        
    }
    
    @IBAction func locationCheckBtnClick(_ sender: Any) {
        self.circleView.startAnimating()
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                print("No access")
                locationImageOn.image = UIImage(named: "google-maps")
                self.openSetting()
                
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
                locationImageOn.image = UIImage(named: "placeholder")
                
            default:
                print("...")
            }
        } else {
           
            locationImageOn.image = UIImage(named: "custom_pin")
            print("Location services are not enabled")
            self.openSetting()
        }
        
    }
    
    func openSetting() {
        let alertController = UIAlertController (title: "Title", message: "Go to Settings?", preferredStyle: .alert)
           let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
               guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                   return
               }
               if UIApplication.shared.canOpenURL(settingsUrl) {
                   UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                       print("Settings opened: \(success)")})}
           }
           alertController.addAction(settingsAction)
           let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
           alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    @IBAction func networkCheckBtnClick(_ sender: Any) {
        self.wifiView.startAnimating()
        monitor.start(queue: queue)
        monitor.pathUpdateHandler = { path in
            if path.status == .satisfied {
                print("Internet connection is available.")
                // Perform actions when internet is available
                self.locationImageOff.image = UIImage(named: "wifi")
                
            } else {
                print("Internet connection is not available.")
                // Perform actions when internet is not available
                self.locationImageOff.image = UIImage(named: "communication")
                self.openSetting()
            }
        }
    }
    
    @IBAction func checkNotificationBtnClick(_ sender: Any) {
        self.notificationsView.startAnimating()
        current.getNotificationSettings(completionHandler: { permission in
            switch permission.authorizationStatus  {
            case .authorized:
                print("User granted permission for notification")
                self.notificationImage.image = UIImage(named: "alarm-on")
            case .denied, .notDetermined, .ephemeral, .provisional:
                print("User denied notification permission")
                self.openSetting()
                self.notificationImage.image = UIImage(named: "silent")
            @unknown default:
                print("Unknow Status")
                self.notificationImage.image = UIImage(named: "silent")
            }
        })
        
       
    }
    
    @IBAction func indexChanged(sender: UISegmentedControl) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            mapView.isHidden = true
            pdfView.isHidden = false
            networkView.isHidden = true
        case 1:
            mapView.isHidden = false
            pdfView.isHidden = true
            networkView.isHidden = true
        case 2:
            mapView.isHidden = true
            pdfView.isHidden = true
            networkView.isHidden = false
            
        default:
            break;
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if AppConstants.Lat == ""{
            
        }else{
            let position = CLLocationCoordinate2DMake(Double(AppConstants.Lat)!, Double(AppConstants.Log)!)
            mapView.animate(toLocation: position) }
    }
   
    func convertPDFToImages(pdfURL: URL) -> [UIImage]? {
        guard let pdfDocument = PDFDocument(url: pdfURL) else {
            return nil
        }
        
        for pageNum in 0..<pdfDocument.pageCount {
            if let pdfPage = pdfDocument.page(at: pageNum) {
                let pdfPageSize = pdfPage.bounds(for: .mediaBox)
                let renderer = UIGraphicsImageRenderer(size: pdfPageSize.size)
                let image = renderer.image { ctx in
                    UIColor.white.set()
                    ctx.fill(pdfPageSize)
                    ctx.cgContext.translateBy(x: 0.0, y: pdfPageSize.size.height)
                    ctx.cgContext.scaleBy(x: 1.0, y: -1.0)
                    pdfPage.draw(with: .mediaBox, to: ctx.cgContext)
                }
                images.append(image)
            }
        }
        return images
    }
    
   
    @IBAction func sendNotificationButtonTapped(_ sender: Any) {
//        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
//            guard settings.authorizationStatus == .authorized else { return }
//            let content = UNMutableNotificationContent()
//            content.categoryIdentifier = "debitOverdraftNotification"
//            content.title = "DEBIT OVERDRAFT NOTICE!"
//            content.subtitle = "Exceeded balance by $300.00."
//            content.body = "One-time overdraft fee is $25. Should we cover transaction?"
//            content.sound = UNNotificationSound.default
//            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
//            let uuidString = UUID().uuidString
//            let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
//            UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
//        }
        
       // showLiveNotification()
        
    }
}

extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        guard status == .authorizedWhenInUse else {
            return
        }
        locationManager.requestLocation()
        mapView.isMyLocationEnabled = true
        mapView.settings.myLocationButton = true
    }
    func locationManager(_ manager: CLLocationManager,didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else {
            return
        }
        mapView.camera = GMSCameraPosition(target: location.coordinate,zoom: 15,bearing: 0,viewingAngle: 0)
    }
    func locationManager(_ manager: CLLocationManager,didFailWithError error: Error) {
        print(error)
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell
        cell.imagesPDF.image = images[indexPath.row]
        return cell
    }
}

