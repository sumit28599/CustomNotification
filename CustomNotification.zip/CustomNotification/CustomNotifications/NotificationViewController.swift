//
//  NotificationViewController.swift
//  CustomNotifications
//
//  Created by apple on 12/02/24.
//

import UIKit
import UserNotifications
import WidgetKit

class NotificationViewController: UIViewController, UNNotificationContentExtension {

    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var bodyLabel: UILabel!
    @IBOutlet weak var footerLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    func didReceive(_ notification: UNNotification) {
         let content = notification.request.content
        subtitleLabel.text = content.title
        bodyLabel.text = content.body

         // Handle your widget content here
         if let widgetContent = content.userInfo["widgetContent"] as? YourWidgetContent {
             subtitleLabel.text = widgetContent.title
             bodyLabel.text = widgetContent.description
         }
     }
}
